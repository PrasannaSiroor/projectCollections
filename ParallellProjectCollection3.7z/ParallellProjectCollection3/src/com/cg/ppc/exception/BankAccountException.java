package com.cg.ppc.exception;

public class BankAccountException extends Exception{
	public BankAccountException(String message){
		super(message);
	}
}
